var Alexa = require('alexa-sdk');

var handlers = {
    'Unhandled': function() {
       this.emit(':ask', 'Sorry, that is not a human being, try asking for a real person');
     },
     'LaunchRequest': function () {
         this.emit(':tell','Boom, initialized bro');
     },
    'divinator': function() {
        var speechOutput = 'who is mark';
        var repromptSpeech = 'mark is rodriguez';

        var person = this.event.request.intent.slots.person.value;
        switch(person) {
          case 'mark':
            this.emit(':tell', repromptSpeech);
            break
        }
    }
};

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.registerHandlers(handlers);
    alexa.execute();
};
